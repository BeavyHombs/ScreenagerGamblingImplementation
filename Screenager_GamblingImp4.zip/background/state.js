/**
 * FocusLock — Shared Storage State Helpers
 *
 * Centralises all reads and writes to chrome.storage.local so that every
 * other module imports from one place.
 *
 * @module background/state
 */

/** Keys used in chrome.storage.local */
export const KEYS = {
    TIMER: 'timer',
    SETTINGS: 'settings',
    ASSIGNMENTS: 'assignments',
    GAME: 'game',
};

/** Default settings */
export const DEFAULT_SETTINGS = {
    difficulty: 'STANDARD',
    baseMinutes: 120,
    blockedSites: null,
    enableChallengeMode: true,
};

/** Default timer state */
export const DEFAULT_TIMER = {
    endTime: null,
    earnedSeconds: 0,
};

/** Default betting game state */
export const DEFAULT_GAME = {
    plays: 0,
    wins: 0,
    losses: 0,
    lastResult: null,
};

// ─── Getters ────────────────────────────────────────────────────────────────

export async function getTimer() {
    const result = await chrome.storage.local.get(KEYS.TIMER);
    return result[KEYS.TIMER] ?? { ...DEFAULT_TIMER };
}

export async function getSettings() {
    const result = await chrome.storage.local.get(KEYS.SETTINGS);
    return result[KEYS.SETTINGS] ?? { ...DEFAULT_SETTINGS };
}

export async function getAssignments() {
    const result = await chrome.storage.local.get(KEYS.ASSIGNMENTS);
    return result[KEYS.ASSIGNMENTS] ?? { raw: [], lastSync: null };
}

export async function getGame() {
    const result = await chrome.storage.local.get(KEYS.GAME);
    return result[KEYS.GAME] ?? { ...DEFAULT_GAME };
}

// ─── Setters ────────────────────────────────────────────────────────────────

export async function saveTimer(timerObj) {
    await chrome.storage.local.set({ [KEYS.TIMER]: timerObj });
}

export async function saveSettings(settingsObj) {
    await chrome.storage.local.set({ [KEYS.SETTINGS]: settingsObj });
}

export async function saveAssignments(assignmentsObj) {
    await chrome.storage.local.set({ [KEYS.ASSIGNMENTS]: assignmentsObj });
}

export async function saveGame(gameObj) {
    await chrome.storage.local.set({ [KEYS.GAME]: gameObj });
}
