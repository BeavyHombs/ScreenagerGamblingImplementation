/**
 * FocusLock — MV3 Service Worker
 *
 * Responsibilities:
 *  1. Uses chrome.alarms to schedule blocking exactly when `endTime` is reached
 *  2. Activates DNR rules via blocker.js when time is up
 *  3. Handles messages from popup (GET_STATE, SET_REMAINING, SETTINGS_UPDATED, PLAY_CHALLENGE)
 *
 * @module background/service-worker
 */

import { computeFromRaw } from '../engine/formula.js';
import { activateBlocking, deactivateBlocking } from './blocker.js';
import {
    getTimer,
    getSettings,
    getAssignments,
    getGame,
    saveTimer,
    saveAssignments,
    saveGame,
} from './state.js';

const ALARM_NAME = 'focuslock-block';
const MIN_BET_SECONDS = 5 * 60;
const MAX_BET_SECONDS = 30 * 60;

// ─── Install / Startup ──────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
    console.log('[FocusLock] Extension installed.');
    await seedDemoData();
    await checkState();
});

chrome.runtime.onStartup.addListener(async () => {
    console.log('[FocusLock] Browser started.');
    await seedDemoData();
    await checkState();
});

/** Seed demo data on first install so the popup has something to show. */
async function seedDemoData() {
    const existing = await getAssignments();
    if (existing.raw && existing.raw.length > 0) return;

    const demoAssignments = [
        { title: 'Chapter 12 Reading Questions', earnedPoints: '45', totalPoints: '50', status: 'graded', dueDate: todayMinus(1) },
        { title: 'Lab Report: Photosynthesis', earnedPoints: '88', totalPoints: '100', status: 'graded', dueDate: todayMinus(2) },
        { title: 'Spanish Vocab Unit 8 Quiz', earnedPoints: '18', totalPoints: '20', status: 'graded', dueDate: todayMinus(3) },
        { title: 'Geometry Proof Worksheet', earnedPoints: '27', totalPoints: '30', status: 'graded', dueDate: todayMinus(4) },
        { title: 'History Essay: Civil Rights', earnedPoints: '0', totalPoints: '50', status: 'missing', dueDate: todayMinus(2) },
    ];

    await saveAssignments({ raw: demoAssignments, lastSync: Date.now() });

    const settings = await getSettings();
    const earnedMinutes = computeFromRaw(demoAssignments, settings.difficulty, settings.baseMinutes);
    const earnedSeconds = Math.round(earnedMinutes * 60);

    await saveTimer({
        endTime: Date.now() + (earnedSeconds * 1000),
        earnedSeconds,
    });

    console.log(`[FocusLock] Demo data seeded: ${earnedMinutes.toFixed(1)} min earned from ${demoAssignments.length} assignments.`);
}

function todayMinus(days) {
    const d = new Date();
    d.setDate(d.getDate() - days);
    return d.toISOString().split('T')[0];
}

/** Check current timer and apply blocking or schedule the alarm. */
async function checkState() {
    const timer = await getTimer();

    await chrome.alarms.clear(ALARM_NAME);

    if (timer.endTime === null || timer.endTime <= Date.now()) {
        console.log('[FocusLock] Timer expired. Activating block.');
        await activateBlocking();
    } else {
        console.log(`[FocusLock] Timer active. Blocking suspended until ${new Date(timer.endTime).toLocaleTimeString()}`);
        await deactivateBlocking();
        chrome.alarms.create(ALARM_NAME, { when: timer.endTime });
    }
}

// ─── Alarm Tick ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === ALARM_NAME) {
        console.log('[FocusLock] Alarm fired — time is up.');
        await checkState();
    }
});

// ─── Message Handling ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    handleMessage(message).then(sendResponse).catch((err) => {
        console.error('[FocusLock] Message handler error:', err);
        sendResponse({ error: err.message });
    });
    return true;
});

async function handleMessage(message) {
    switch (message.type) {
        case 'GET_STATE': {
            const [timer, settings, assignments, game] = await Promise.all([
                getTimer(),
                getSettings(),
                getAssignments(),
                getGame(),
            ]);
            return { timer, settings, assignments, game };
        }

        case 'SETTINGS_UPDATED': {
            const { settings } = message;
            await chrome.storage.local.set({ settings });

            const assignments = await getAssignments();
            if (assignments.raw && assignments.raw.length > 0) {
                const earnedMinutes = computeFromRaw(
                    assignments.raw,
                    settings.difficulty,
                    settings.baseMinutes
                );
                const earnedSeconds = Math.round(earnedMinutes * 60);

                await saveTimer({
                    earnedSeconds,
                    endTime: earnedSeconds > 0 ? Date.now() + (earnedSeconds * 1000) : null,
                });
                await checkState();
            } else {
                await deactivateBlocking();
            }
            return { success: true };
        }

        case 'SET_REMAINING': {
            const { seconds } = message;
            const timer = await getTimer();
            if (seconds <= 0) {
                await saveTimer({ ...timer, endTime: null });
            } else {
                await saveTimer({ ...timer, endTime: Date.now() + seconds * 1000 });
            }
            await checkState();
            return { success: true };
        }

        case 'PLAY_CHALLENGE': {
            return await playChallenge(message.challengeType, message.betSeconds);
        }
        case 'PLACE_BET': {
            return await playChallenge('draw', message.betSeconds);
        }

        default:
            return { error: `Unknown message type: ${message.type}` };
    }
}

async function playChallenge(challengeType, rawBetSeconds) {
    const betSeconds = normalizeBetSeconds(rawBetSeconds);
    if (!Number.isFinite(betSeconds)) {
        return { error: 'Invalid challenge amount.' };
    }

    const [timer, game, settings] = await Promise.all([getTimer(), getGame(), getSettings()]);
    const now = Date.now();
    const remainingSeconds = timer.endTime ? Math.max(0, Math.floor((timer.endTime - now) / 1000)) : 0;

    if (settings.enableChallengeMode === false) {
        return { error: 'Challenge mode is disabled in settings.' };
    }

    if (remainingSeconds <= 0 || timer.earnedSeconds <= 0) {
        return { error: 'No bonus minutes left to risk.' };
    }

    if (betSeconds < MIN_BET_SECONDS) {
        return { error: 'Minimum challenge is 5 minutes.' };
    }

    if (betSeconds > MAX_BET_SECONDS) {
        return { error: 'Maximum challenge is 30 minutes.' };
    }

    if (betSeconds > remainingSeconds) {
        return { error: 'Challenge amount cannot exceed your remaining time.' };
    }

    const result = resolveChallenge(challengeType);
    if (result.error) {
        return result;
    }

    const delta = result.outcome === 'WIN' ? betSeconds : -betSeconds;
    const nextEarnedSeconds = Math.max(0, timer.earnedSeconds + delta);
    const nextRemainingSeconds = Math.max(0, remainingSeconds + delta);

    await saveTimer({
        earnedSeconds: nextEarnedSeconds,
        endTime: nextRemainingSeconds > 0 ? now + (nextRemainingSeconds * 1000) : null,
    });

    const nextGame = {
        plays: (game.plays ?? 0) + 1,
        wins: (game.wins ?? 0) + (result.outcome === 'WIN' ? 1 : 0),
        losses: (game.losses ?? 0) + (result.outcome === 'LOSS' ? 1 : 0),
        lastResult: {
            challengeType: result.challengeType,
            challengeLabel: result.challengeLabel,
            outcome: result.outcome,
            betSeconds,
            summary: result.summary,
            changedAt: now,
        },
    };
    await saveGame(nextGame);

    await checkState();

    return {
        success: true,
        result: nextGame.lastResult,
        timer: {
            earnedSeconds: nextEarnedSeconds,
            endTime: nextRemainingSeconds > 0 ? now + (nextRemainingSeconds * 1000) : null,
        },
        game: nextGame,
    };
}

function resolveChallenge(challengeType) {
    switch (challengeType) {
        case 'coin': {
            const didWin = randomChance(0.45);
            return {
                challengeType,
                challengeLabel: 'Coin Flip',
                outcome: didWin ? 'WIN' : 'LOSS',
                summary: didWin ? 'Weighted coin: heads. You won this round.' : 'Weighted coin: tails. You lost this round.',
            };
        }
        case 'draw': {
            const card = drawCard();
            const didWin = card >= 8;
            return {
                challengeType,
                challengeLabel: 'Draw a Card',
                outcome: didWin ? 'WIN' : 'LOSS',
                summary: `You drew ${formatCard(card)}. ${didWin ? '8 or higher wins.' : 'That was not high enough.'}`,
            };
        }
        case 'beat15': {
            const first = drawCard();
            const second = drawCard();
            const total = first + second;
            const didWin = total > 15;
            return {
                challengeType,
                challengeLabel: 'Beat 15',
                outcome: didWin ? 'WIN' : 'LOSS',
                summary: `You drew ${formatCard(first)} and ${formatCard(second)} for ${total}. ${didWin ? 'You beat 15.' : 'You did not beat 15.'}`,
            };
        }
        case 'higherLower': {
            const scenarios = [
                { first: 4, second: 9, guess: 'higher', win: true },
                { first: 10, second: 6, guess: 'higher', win: false },
                { first: 9, second: 3, guess: 'lower', win: true },
                { first: 5, second: 12, guess: 'lower', win: false },
                { first: 7, second: 13, guess: 'higher', win: true },
                { first: 11, second: 8, guess: 'higher', win: false },
                { first: 8, second: 2, guess: 'lower', win: true },
                { first: 6, second: 10, guess: 'lower', win: false },
                { first: 3, second: 11, guess: 'higher', win: true },
                { first: 12, second: 7, guess: 'higher', win: false },
                { first: 10, second: 4, guess: 'lower', win: true },
                { first: 2, second: 8, guess: 'higher', win: false },
                { first: 13, second: 5, guess: 'lower', win: true },
                { first: 6, second: 1, guess: 'higher', win: false },
                { first: 7, second: 3, guess: 'higher', win: false },
            ];
            const scenario = scenarios[randomIndex(scenarios.length)];
            return {
                challengeType,
                challengeLabel: 'Higher or Lower',
                outcome: scenario.win ? 'WIN' : 'LOSS',
                summary: `First card ${formatCard(scenario.first)}. You called ${scenario.guess}. Next card ${formatCard(scenario.second)}. ${scenario.win ? 'Good call.' : 'Wrong read.'}`,
            };
        }
        default:
            return { error: 'Unknown challenge type.' };
    }
}

function drawCard() {
    return randomIndex(13) + 1;
}

function formatCard(value) {
    if (value === 1) return 'A';
    if (value === 11) return 'J';
    if (value === 12) return 'Q';
    if (value === 13) return 'K';
    return String(value);
}

function randomChance(probability) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    return (buffer[0] / 0x100000000) < probability;
}

function randomIndex(max) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    return buffer[0] % max;
}

function normalizeBetSeconds(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return NaN;
    return Math.round(numeric);
}

