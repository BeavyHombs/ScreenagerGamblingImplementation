/**
 * FocusLock — Popup Script
 *
 * Wires the dashboard UI to the service worker state.
 * Uses a live countdown loop running 60fps to smoothly animate ring and clock.
 */

'use strict';

const RING_CIRCUMFERENCE = 553.0;
const MIN_BET_MINUTES = 5;

const timerDisplay = document.getElementById('timer-display');
const timerEarned = document.getElementById('timer-earned');
const ringProgress = document.getElementById('ring-progress');
const statusBanner = document.getElementById('status-banner');
const statusText = document.getElementById('status-text');
const statAssignments = document.getElementById('stat-assignments-val');
const statAvgGrade = document.getElementById('stat-avg-grade-val');
const statMissing = document.getElementById('stat-missing-val');
const diffStandard = document.getElementById('diff-standard');
const diffHard = document.getElementById('diff-hard');
const messageBar = document.getElementById('message-bar');
const betChoices = Array.from(document.querySelectorAll('.bet-choice'));
const challengeChoices = Array.from(document.querySelectorAll('.challenge-choice'));
const betSubmit = document.getElementById('bet-submit');
const betStats = document.getElementById('bet-stats');
const betPreview = document.getElementById('bet-preview');

let currentDifficulty = 'STANDARD';
let latestTimer = { endTime: null, earnedSeconds: 0 };
let latestGame = { plays: 0, wins: 0, losses: 0, lastResult: null };
let challengeModeEnabled = true;
let renderLoopId = null;
let hasLoadedData = false;
let selectedBetMinutes = MIN_BET_MINUTES;
let selectedChallengeType = 'draw';
let isPlacingBet = false;

const CHALLENGE_DETAILS = {
    draw: 'Draw a card. 8 or higher wins.',
    higherLower: 'A second card is drawn behind the scenes. Correct call wins.',
    beat15: 'Two cards are drawn. Total above 15 wins.',
    coin: 'A weighted coin gives you a 45% shot to win.'
};

async function init() {
    await loadDataFromBackground();

    setInterval(loadDataFromBackground, 10000);

    diffStandard.addEventListener('click', () => setDifficulty('STANDARD'));
    diffHard.addEventListener('click', () => setDifficulty('HARD'));
    betChoices.forEach((button) => {
        button.addEventListener('click', () => selectBetMinutes(Number(button.dataset.betMinutes)));
    });
    challengeChoices.forEach((button) => {
        button.addEventListener('click', () => selectChallengeType(button.dataset.challengeType));
    });
    betSubmit.addEventListener('click', playChallenge);

    renderLoopId = requestAnimationFrame(renderLoop);
    window.addEventListener('unload', () => cancelAnimationFrame(renderLoopId));
}

async function loadDataFromBackground() {
    try {
        const response = await sendMessage({ type: 'GET_STATE' });
        if (response.error) throw new Error(response.error);

        latestTimer = response.timer;
        latestGame = response.game ?? latestGame;
        challengeModeEnabled = response.settings?.enableChallengeMode !== false;
        hasLoadedData = true;
        renderStatic(response);
    } catch (err) {
        console.error('Could not reach background worker:', err.message);
        showMessage('Could not reach FocusLock right now.', true);
    }
}

function renderStatic({ settings, assignments, game }) {
    currentDifficulty = settings.difficulty ?? 'STANDARD';
    diffStandard.classList.toggle('active', currentDifficulty === 'STANDARD');
    diffHard.classList.toggle('active', currentDifficulty === 'HARD');

    const raw = assignments?.raw ?? [];
    const graded = raw.filter((a) => a.status === 'graded' || a.status === 'turned-in');
    const missing = raw.filter((a) => a.status === 'missing');

    statAssignments.textContent = graded.length || 'none';
    statMissing.textContent = missing.length || '0';

    document.querySelector('.shell').classList.remove('loading');

    if (graded.length > 0) {
        const grades = graded.map((a) => {
            const e = parseFloat(a.earnedPoints) || 0;
            const t = parseFloat(a.totalPoints) || 0;
            return t > 0 ? (e / t) * 100 : 0;
        });
        const avg = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
        statAvgGrade.textContent = `${avg.toFixed(0)}%`;
    } else {
        statAvgGrade.textContent = '–';
    }

    const challengeSection = document.querySelector('.bet-card');
    const challengeLabel = document.querySelector('.section-label:last-of-type');
    if (challengeSection) challengeSection.hidden = !challengeModeEnabled;
    if (challengeLabel) challengeLabel.hidden = !challengeModeEnabled;

    renderBetMeta(game ?? latestGame);
    updateChallengePreview();
}

function renderLoop() {
    if (!hasLoadedData) {
        renderLoopId = requestAnimationFrame(renderLoop);
        return;
    }

    const earned = latestTimer.earnedSeconds ?? 0;
    const remaining = getRemainingSeconds();

    timerDisplay.textContent = formatTime(remaining);
    timerEarned.textContent = `of ${formatTime(earned)} earned`;

    const fraction = earned > 0 ? remaining / earned : 0;
    const offset = RING_CIRCUMFERENCE * (1 - Math.max(0, Math.min(1, fraction)));
    ringProgress.style.strokeDashoffset = offset;
    document.querySelector('.ring-svg').setAttribute('aria-valuenow', Math.round(Math.max(0, Math.min(1, fraction)) * 100));

    const isBlocked = remaining <= 0;
    const isWarning = !isBlocked && remaining < 600;

    ringProgress.classList.toggle('blocked', isBlocked);
    ringProgress.classList.toggle('warn', isWarning);
    timerDisplay.classList.toggle('warn', isWarning);
    timerDisplay.classList.toggle('accent', !isWarning && !isBlocked);

    statusBanner.hidden = !isBlocked;
    if (isBlocked) {
        statusText.textContent = 'Screen time blocked';
    }

    syncBetAvailability(remaining);

    renderLoopId = requestAnimationFrame(renderLoop);
}

async function setDifficulty(mode) {
    if (currentDifficulty === mode) return;

    currentDifficulty = mode;
    diffStandard.classList.toggle('active', mode === 'STANDARD');
    diffHard.classList.toggle('active', mode === 'HARD');
    diffStandard.setAttribute('aria-pressed', String(mode === 'STANDARD'));
    diffHard.setAttribute('aria-pressed', String(mode === 'HARD'));

    const result = await sendMessage({ type: 'GET_STATE' });
    const settings = result.settings ?? {};
    settings.difficulty = mode;

    await sendMessage({ type: 'SETTINGS_UPDATED', settings });
    await loadDataFromBackground();
}

function selectBetMinutes(minutes) {
    selectedBetMinutes = minutes;
    betChoices.forEach((button) => {
        const isActive = Number(button.dataset.betMinutes) === minutes;
        button.classList.toggle('active', isActive);
        button.setAttribute('aria-pressed', String(isActive));
    });
}

function selectChallengeType(type) {
    selectedChallengeType = type;
    challengeChoices.forEach((button) => {
        const isActive = button.dataset.challengeType === type;
        button.classList.toggle('active', isActive);
        button.setAttribute('aria-pressed', String(isActive));
    });
    updateChallengePreview();
}

function updateChallengePreview(lastResult = null) {
    if (!betPreview) return;
    if (lastResult?.summary) {
        betPreview.textContent = lastResult.summary;
        return;
    }
    betPreview.textContent = CHALLENGE_DETAILS[selectedChallengeType] ?? '';
}

async function playChallenge() {
    if (isPlacingBet) return;

    isPlacingBet = true;
    betSubmit.disabled = true;
    betSubmit.textContent = 'Shuffling…';

    try {
        const response = await sendMessage({ type: 'PLAY_CHALLENGE', challengeType: selectedChallengeType, betSeconds: selectedBetMinutes * 60 });
        if (response.error) {
            showMessage(response.error, true);
            return;
        }

        latestTimer = response.timer ?? latestTimer;
        latestGame = response.game ?? latestGame;
        renderBetMeta(latestGame);

        const won = response.result?.outcome === 'WIN';
        const minutes = Math.round((response.result?.betSeconds ?? 0) / 60);
        updateChallengePreview(response.result ?? null);
        showMessage(won ? `Nice. You gained ${minutes} bonus minutes.` : `Round lost. You gave up ${minutes} bonus minutes.`, !won);
    } catch (err) {
        console.error('Bet failed:', err);
        showMessage('Could not place bet.', true);
    } finally {
        isPlacingBet = false;
        betSubmit.disabled = false;
        betSubmit.textContent = 'Play challenge';
    }
}

function renderBetMeta(game) {
    const plays = game?.plays ?? 0;
    const wins = game?.wins ?? 0;
    const losses = game?.losses ?? 0;

    if (plays === 0) {
        betStats.textContent = '0 rounds played';
        return;
    }

    betStats.textContent = `${wins}W · ${losses}L · ${plays} rounds`; 
}

function syncBetAvailability(remainingSeconds) {
    const minAvailableSeconds = selectedBetMinutes * 60;
    const canBet = !isPlacingBet && remainingSeconds >= minAvailableSeconds && remainingSeconds >= (MIN_BET_MINUTES * 60);

    betSubmit.disabled = !canBet;
    betChoices.forEach((button) => {
        const optionSeconds = Number(button.dataset.betMinutes) * 60;
        const unavailable = optionSeconds > remainingSeconds;
        button.disabled = unavailable;
        if (unavailable && button.classList.contains('active')) {
            const fallback = betChoices.find((choice) => !choice.disabled);
            if (fallback) selectBetMinutes(Number(fallback.dataset.betMinutes));
        }
    });
}

function getRemainingSeconds() {
    if (!latestTimer.endTime) return 0;
    return Math.max(0, Math.floor((latestTimer.endTime - Date.now()) / 1000));
}

function showMessage(text, isError = false) {
    if (!text) {
        messageBar.hidden = true;
        messageBar.textContent = '';
        messageBar.classList.remove('error');
        return;
    }

    messageBar.hidden = false;
    messageBar.textContent = text;
    messageBar.classList.toggle('error', isError);
}

function sendMessage(payload) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(payload, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(response ?? {});
            }
        });
    });
}

function formatTime(totalSeconds) {
    if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return '00:00';
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

init();
